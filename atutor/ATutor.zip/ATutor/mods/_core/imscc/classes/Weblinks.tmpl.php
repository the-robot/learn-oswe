<?php echo '<?xml version="1.0" encoding="UTF-8"?>' ?>
<wl:webLink
   xmlns:wl="http://www.imsglobal.org/xsd/imswl_v1p0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.imsglobal.org/xsd/imswl_v1p0 http://www.imsglobal.org/profile/cc/ccv1p0/derived_schema/domainProfile_5/imswl_v1p0_localised.xsd">
  <title><?php echo $this->title; ?></title>
  <url href="<?php echo $this->url_href; ?>" target="<?php echo $this->url_target; ?>"/>
</wl:webLink>

