<?php

$dirs = array();
$dirs['content/'] = AT_CONTENT_DIR . '?' . DIRECTORY_SEPARATOR; // course_id gets added to the end

?>