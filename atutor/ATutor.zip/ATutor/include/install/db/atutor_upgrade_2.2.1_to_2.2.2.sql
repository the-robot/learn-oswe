# DB Upgrade for ATutor 2.2.2, no database changes

UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'ATutor' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'Fluid' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'ATutor Classic' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'Blumin' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'Greenmin' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'ATutor 1.5' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'Mobile' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'ATutor 1.6' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'ATutor 2.0' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'ATutor 2.1' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'IDI Theme' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'Simple' LIMIT 1 ;
UPDATE `themes` SET `version` = '2.2.2' WHERE `title` = 'ATutorSpaces' LIMIT 1 ;