<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>News Feeds</h2>
	<p>Instructors may display syndicated feeds in the side menu of their courses. The choice of feeds available to them is controlled by the administrator. Feeds may be managed by going to the <em>News Feeds</em> link under the System Preferences tab. </p>

<?php require('../common/body_footer.inc.php'); ?>
