<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Introduction</h2>
	<p>Welcome to the ATutor Administrator Documentation! This documentation is intended for those who manage ATutor systems. Also see the <a href="../instructor/" target="_top">Instructor Documentation</a> for more about creating and managing courses. </p>

<?php require('../common/body_footer.inc.php'); ?>