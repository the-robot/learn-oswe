<?php
/************************************************************************/
/* ATutor																*/
/************************************************************************/
/* Copyright (c) 2002-2010                                              */
/* Inclusive Design Institute                                           */
/* http://atutor.ca                                                     */
/* This program is free software. You can redistribute it and/or        */
/* modify it under the terms of the GNU General Public License          */
/* as published by the Free Software Foundation.                        */
/************************************************************************/
// $Id: index.php 5866 2005-12-15 16:16:03Z joel $

$parts = pathinfo($_SERVER['PHP_SELF']);

$dir_parts = explode('/', $parts['dirname']);
$last_dir_name = end($dir_parts);

header('Location: ../index.php?' . $last_dir_name);
exit;
?>