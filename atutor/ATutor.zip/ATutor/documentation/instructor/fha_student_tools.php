<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2008-11-04 14:52:54 -0500 (Tue, 04 Nov 2008) $'; ?>

<h2>Student Tools Setup</h2>
	<p>Tools that might be added through the <a href="student_tools.php">Course Tools</a> utility, can be added to a separate tools page, potentially removing tools from the course home page. Select from the available tools those that you want to appear on the Student Tools page. To enable the separate student tools page add it when configuring Course Tools, either as a home page icon, or a main navigation tab.</p>



<?php require('../common/body_footer.inc.php'); ?>